package com.hello.entity;

public class BaseEntity {

}
