package com.hello;

import android.app.Activity;
import android.os.Bundle;

public class QuestionMyErrorsActivity extends Activity{
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.activity_question_doproblem_record);
	}
}
