package com.hello.util;

public class Constant {
	public static final String DOMAIN_URL = "http://www.youeclass.com/";
}
