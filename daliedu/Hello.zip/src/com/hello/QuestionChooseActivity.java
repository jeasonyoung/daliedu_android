package com.hello;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hello.adapter.ChooseListAdapter;
import com.hello.adapter.ChooseListAdapter2;
import com.hello.adapter.QuestionGridAdapter2;
import com.hello.dao.PaperDao;
import com.hello.entity.ExamErrorQuestion;
import com.hello.entity.ExamQuestion;
import com.hello.entity.ExamRecord;
import com.hello.entity.ExamRule;
import com.umeng.analytics.MobclickAgent;

public class QuestionChooseActivity extends Activity implements OnClickListener{
	private ImageButton returnbtn,scoreFlexImg;
	private LinearLayout scoreLayout,loadingLayout,examDirectoryLayout,nodataLayout,lookBtn,doAgainBtn;
	private GridView scoreGridView;
	private ListView questionListView;
	private List<ExamRule> ruleList;
	private List<ExamQuestion> questionList;
	private String action,ruleListJson,questionListJson;
	private String[] data;
	private Intent intent;
	private String username,paperId;
	private SparseBooleanArray isDone;
	private PaperDao dao;
	private ExamRecord r;
	private Gson gson ;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.activity_question_exam_directory);
		findView();
		initData();
	}
	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		initView();
		super.onStart();
	}
	private void findView()
	{
		this.returnbtn = (ImageButton) this.findViewById(R.id.returnbtn);
		this.scoreFlexImg = (ImageButton) this.findViewById(R.id.scoreFlexImg);
		this.scoreLayout = (LinearLayout) this.findViewById(R.id.exam_scoreLayout);
		this.loadingLayout = (LinearLayout) this.findViewById(R.id.loadingLayout);
		this.nodataLayout = (LinearLayout) this.findViewById(R.id.nodataLayout);
		this.examDirectoryLayout = (LinearLayout) this.findViewById(R.id.examDirectoryLayout);
		this.scoreGridView = (GridView) this.findViewById(R.id.scoreGridView);
		this.questionListView = (ListView) this.findViewById(R.id.question_directoryListView);
		this.lookBtn = (LinearLayout) this.findViewById(R.id.question_directory_lookBtn_Layout);
		this.doAgainBtn = (LinearLayout) this.findViewById(R.id.quesiton_directory_repeatBtn_layout);
		this.scoreFlexImg.setOnClickListener(this);
		this.returnbtn.setOnClickListener(this);
		this.lookBtn.setOnClickListener(this);
		this.doAgainBtn.setOnClickListener(this);
	}
	private void initData()
	{
		intent = this.getIntent();
		this.action = intent.getStringExtra("action");
		Type type = new TypeToken<ArrayList<ExamRule>>(){}.getType();
		gson = new Gson();
		this.ruleListJson = intent.getStringExtra("ruleListJson");
		this.ruleList = gson.fromJson(ruleListJson, type);
		this.isDone = gson.fromJson(intent.getStringExtra("isDone"), SparseBooleanArray.class);
		this.r = gson.fromJson(intent.getStringExtra("record"), ExamRecord.class);
		this.questionListJson =  intent.getStringExtra("questionList");
		if(questionListJson != null)
		{
			this.questionList = gson.fromJson(questionListJson, new TypeToken<ArrayList<ExamQuestion>>(){}.getType());
		}
		this.username = intent.getStringExtra("username");
		this.paperId = intent.getStringExtra("paperid");
		System.out.println(paperId+"  "+username);
		this.dao = new PaperDao(this);
	}
	private void initView()
	{
		if("chooseQuestion".equals(action))
		{
			this.scoreLayout.setVisibility(View.GONE);
			this.loadingLayout.setVisibility(View.GONE);
			if(this.ruleList!=null&&this.ruleList.size()>0)
			{
				this.questionListView.setAdapter(new ChooseListAdapter(this,this,ruleList,isDone));
			}else
			{
				this.nodataLayout.setVisibility(View.VISIBLE);
			}
		}else if("submitPaper".equals(action)||"showResult".equals(action))
		{
			this.scoreLayout.setVisibility(View.VISIBLE);
			this.data = new String[10];
			this.data[0] = "�����ܷ�:"+intent.getIntExtra("paperScore",0)+"��";//�ܷ�
			this.data[1] = "������ʱ:"+intent.getIntExtra("paperTime",0)+"����";//��ʱ
			this.data[2] = "���ε÷�:"+intent.getDoubleExtra("userScore",0)+"��";//���ε÷�[��ɫ]
			this.data[3] = "�����ʱ:"+intent.getIntExtra("useTime",0)+"����";//��ʱ
			this.data[4] = "����:"+isDone.size()+"��";//����
			this.data[5] = "δ��:"+(questionList.size()-isDone.size())+"��";//δ��
			int right = getRightNum();
			this.data[6] = "����:"+right+"��";//����
			this.data[7] = "����:"+(isDone.size()-right)+"��";//����
			this.data[8] = "����:"+questionList.size()+"��";//������
			if(isDone.size()==0)
			{
				this.data[9] = "��ȷ��:0%";
			}else
				this.data[9] = "��ȷ��:"+(((int)(right*10000/isDone.size())/100.0))+"%";//��ȷ��
			this.scoreGridView.setAdapter(new QuestionGridAdapter2(this,null,data));
			this.questionListView.setAdapter(new ChooseListAdapter2(this,this,questionList,action));
			this.loadingLayout.setVisibility(View.GONE);
		}else
		{
			this.scoreLayout.setVisibility(View.GONE);
			this.questionListView.setAdapter(new ChooseListAdapter2(this,this,questionList,action));
			this.loadingLayout.setVisibility(View.GONE);
		}
	}
	private int getRightNum()
	{
		//�����������⼯
		int count=0;
		for(ExamQuestion q:questionList)
		{
			if(q.getAnswer().equals(q.getUserAnswer()))
			{
				count++;
			}
			if("submitPaper".equals(action)&&q.getUserAnswer()!=null&&!q.getUserAnswer().equals(q.getAnswer()))
			{
				ExamErrorQuestion error = new ExamErrorQuestion(q.getQid(),username,paperId);
				dao.insertError(error);
			}
		}
		return count;
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId())
		{
		case R.id.returnbtn:
			returnMethod();
			break;
		case R.id.scoreFlexImg:
			toggleShowView();
			break;
		case R.id.quesiton_directory_repeatBtn_layout:
			doItAgain();
			break;
		case R.id.question_directory_lookBtn_Layout:
			showAnswer(0);
			break;
		}
	}
	private void returnMethod()
	{
		if("chooseQuestion".equals(action)||"otherChooseQuestion".equals(action))
		{
			this.setResult(50);
			this.finish();
		}else
		{
			this.finish();
		}
	}
	private void toggleShowView()
	{
		if(this.scoreGridView.getVisibility()==View.GONE)
		{
			this.scoreFlexImg.setImageResource(R.drawable.shrink);
			this.scoreGridView.setVisibility(View.VISIBLE);
			return;
		}
		if(this.scoreGridView.getVisibility()==View.VISIBLE)
		{
			this.scoreFlexImg.setImageResource(R.drawable.unfold);
			this.scoreGridView.setVisibility(View.GONE);
			return;
		}
	}
	private void doItAgain()
	{
		if("submitPaper".equals(action))
		{
			Intent data = new Intent();
			data.putExtra("action", "DoExam");
			this.setResult(30, data);
			this.finish();
		}else
		{
			//����DoExamQuestion
			Intent mIntent = new Intent(this,QuestionDoExamActivity2.class);
			mIntent.putExtra("action", "DoExam");
			mIntent.putExtra("paperName", r.getPapername());
			mIntent.putExtra("paperId", r.getPaperId());
			mIntent.putExtra("ruleListJson",ruleListJson);
			mIntent.putExtra("username", username);
			mIntent.putExtra("tempTime", r.getPapertime()*60);
			mIntent.putExtra("paperTime", r.getPapertime());
			mIntent.putExtra("paperScore", r.getPaperscore());
			r.setTempAnswer("");
			r.setIsDone("");
			r.setTempTime(r.getPapertime()*60);
			dao.saveOrUpdateRecord(r);
			setNull4UserAnswer();
			mIntent.putExtra("questionListJson", gson.toJson(questionList));
			this.startActivity(mIntent);
		}
	}
	public void showAnswer(int cursor)
	{
		if("submitPaper".equals(action))
		{
			Intent data = new Intent();
			data.putExtra("action", "showQuestionWithAnswer");  
        	data.putExtra("cursor", 0);  
         	//�����������Լ����ã��������ó�20  
        	this.setResult(20, data);
        	this.finish();
		}else if("chooseQuestion".equals(action)||"otherChooseQuestion".equals(action))
		{
			Intent data=new Intent();  
         	data.putExtra("action", "showQuestionWithAnswer");  
         	data.putExtra("cursor", cursor);  
         	//�����������Լ����ã��������ó�20  
         	this.setResult(20, data);  
         	//�رյ����Activity  
         	this.finish();
		}
		else
		{
			//����DoExamQuestion
			Intent mIntent = new Intent(this,QuestionDoExamActivity2.class);
			mIntent.putExtra("action", "showQuestionWithAnswer");  
			mIntent.putExtra("paperName", r.getPapername());
			mIntent.putExtra("paperId", r.getPaperId());
			mIntent.putExtra("ruleListJson",ruleListJson);
			mIntent.putExtra("username", username);
			mIntent.putExtra("cursor", cursor);
			mIntent.putExtra("tempTime", r.getTempTime());
			mIntent.putExtra("paperTime", r.getPapertime());
			mIntent.putExtra("paperScore", r.getPaperscore());
			mIntent.putExtra("questionListJson", questionListJson);
			this.startActivity(mIntent);
		}
			//��doexamQuestion
	}
	public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
	{
	    if ((paramKeyEvent.getKeyCode() == 4) && (paramKeyEvent.getRepeatCount() == 0))
	    {
	    	if("chooseQuestion".equals(action))
	    	{
	    		this.setResult(50);
				this.finish();
	    		return true;
	    	}
	    }
	    return super.onKeyDown(paramInt, paramKeyEvent);
	}
	private void setNull4UserAnswer() {
		for (ExamQuestion q : questionList) {
			q.setUserAnswer(null);
		}
	}
	@Override
	protected void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
	};
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		MobclickAgent.onResume(this);
		
	}
}
