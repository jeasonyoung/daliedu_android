package com.hello;

import java.util.LinkedList;

import org.json.JSONArray;
import org.json.JSONObject;

import android.app.ListActivity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.hello.adapter.ProblemListAdapter;
import com.hello.customview.PullToRefreshListView;
import com.hello.customview.PullToRefreshListView.OnRefreshListener;
import com.hello.entity.Problem;
import com.hello.util.Constant;
import com.hello.util.HttpConnectUtil;
import com.umeng.analytics.MobclickAgent;
 
public class AnswerMainActivity extends ListActivity implements OnClickListener{   
	private ImageButton returnbtn,refreshbtn;
	private LinearLayout progressLayout,contentLayout;
	private TextView answerInfosText;
	private Button askBtn;
	private String username;
    private LinkedList<Problem> mListItems;
    private ProblemListAdapter mAdapter;
    private int uid;
    private Gson gson;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_answer_main);
        this.returnbtn = (ImageButton) this.findViewById(R.id.returnbtn);
        this.progressLayout = (LinearLayout) this.findViewById(R.id.progressLayout);
        this.contentLayout = (LinearLayout) this.findViewById(R.id.contextLayout);
        this.answerInfosText = (TextView) this.findViewById(R.id.answerInfos_text);
        this.askBtn = (Button) this.findViewById(R.id.ask_btn);
        this.refreshbtn = (ImageButton) this.findViewById(R.id.refreshbtn);
        gson = new Gson();
        Intent intent = this.getIntent();
        this.username = intent.getStringExtra("username");
        this.uid = intent.getIntExtra("uid", 0);
        // Set a listener to be invoked when the list should be refreshed.
        ((PullToRefreshListView) getListView()).setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh() {
                // Do work to refresh the list here.
            	new GetDataTask().execute(Constant.DOMAIN_URL+"mobile/MyQuestions?username="+username);
            }
        });
        this.askBtn.setOnClickListener(this);
        this.returnbtn.setOnClickListener(this);
        this.refreshbtn.setOnClickListener(this);
    }
    @Override
    protected void onStart() {
    	// TODO Auto-generated method stub
    	super.onStart();
    	this.progressLayout.setVisibility(View.VISIBLE);
        this.contentLayout.setVisibility(View.GONE);
        new GetDataTask().execute(Constant.DOMAIN_URL+"mobile/MyQuestions?username="+username);
    }
    private class GetDataTask extends AsyncTask<String, Void, String> {
    	@Override
    	protected void onPreExecute() {
    		// TODO Auto-generate method stub
    		super.onPreExecute();
    	}
        @Override
        protected String doInBackground(String... params) {
            // Simulates a background job.
            try {
            	String result = null;
            	result = HttpConnectUtil.httpGetRequest(AnswerMainActivity.this, params[0]);
            	return result;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            //����json
        	if(mListItems!=null)
        	{
        		mListItems.clear();
        		mListItems.addAll(parseJson(result));
        	}else
        	{
        		mListItems = parseJson(result);
        	}
        	answerInfosText.setText(username+"����"+mListItems.size()+"������");
        	if(mAdapter==null)
        	{
        		mAdapter = new ProblemListAdapter(AnswerMainActivity.this, mListItems);
        		setListAdapter(mAdapter);
        	}
        	else
        	{
        		mAdapter.notifyDataSetChanged();
        	}
        	contentLayout.setVisibility(View.VISIBLE);
        	progressLayout.setVisibility(View.GONE);
            // Call onRefreshComplete when the list has been refreshed.
            ((PullToRefreshListView) getListView()).onRefreshComplete();

            super.onPostExecute(result);
        }
        private LinkedList<Problem> parseJson(String result)
        {
        	LinkedList<Problem> list = new LinkedList<Problem>();
        	try{
        		JSONArray json = new JSONArray(result);
        		int length = json.length();
        		for(int i=0;i<length;i++)
        		{
        			JSONObject obj = json.getJSONObject(i);
        			//String content, String title, String path, String addTime,String answersJson
        			String time = obj.getString("questionAddTime").split("T")[0];
        			Problem p = new Problem(obj.getString("questionContent"),obj.getString("questionTitle"),obj.getString("questionPath"),time,obj.getString("tbAnswers"));
        			list.add(p);
        		}
        		return list;
        	}catch(Exception e)
        	{
        		e.printStackTrace();
        		return list;
        	}
        }
    }
    @Override
    public void onClick(View v) {
    	// TODO Auto-generated method stub
    	switch(v.getId())
    	{
    	case R.id.returnbtn:
    		this.finish();
    		return;
    	case R.id.refreshbtn:
    		refresh();
    		return;
    	case R.id.ask_btn:
    		ask();
    		return;
    	}
    }
    
    @Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		// TODO Auto-generated method stub
    	//��ˢ�µ�list,position��1��ʼ,����header
    	Problem p = this.mListItems.get(position-1);
    	Intent intent = new Intent(this,AnswerInfoActivity.class);
    	intent.putExtra("problem", gson.toJson(p));
    	this.startActivity(intent);
	}

	private void refresh()
    {
		this.progressLayout.setVisibility(View.VISIBLE);
        this.contentLayout.setVisibility(View.GONE);
		new GetDataTask().execute(Constant.DOMAIN_URL+"mobile/MyQuestions?username="+username);
    }
    private void ask()
    {
    	Intent mIntent = new Intent(this,AnswerAskActivity.class);
    	mIntent.putExtra("username", username);
    	mIntent.putExtra("uid", uid);
    	this.startActivity(mIntent);
    }
    @Override
	protected void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
	};
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		MobclickAgent.onResume(this);
		
	}
}