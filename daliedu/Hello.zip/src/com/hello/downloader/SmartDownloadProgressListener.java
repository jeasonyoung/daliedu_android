package com.hello.downloader;

public interface SmartDownloadProgressListener {
	public void onDownloadSize(int size);
}
