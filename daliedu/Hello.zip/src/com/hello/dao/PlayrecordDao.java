package com.hello.dao;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.hello.db.MyDBHelper;
import com.hello.entity.Playrecord;

public class PlayrecordDao {
	private MyDBHelper dbhelper;
	private static final String TAG = "PlayrecordDao";
	public PlayrecordDao(Context context) {
		dbhelper = new MyDBHelper(context);
	}
	//���沥�ż�¼
	public void save(Playrecord record)
	{
		SQLiteDatabase db =  dbhelper.getDatabase(MyDBHelper.WRITE);
		db.beginTransaction();
		try{
				db.execSQL("insert into PlayrecordTab(courseId,currenttime,username)values(?,?,?)",
						new Object[]{record.getCourseId(),record.getCurrentTime(),record.getUsername()});
			db.setTransactionSuccessful();
		}finally{
			db.endTransaction();
		}
		dbhelper.closeDb();
	}
	//�����û���ȡ�����ż�¼
	public List<Playrecord> getRecordList(String username)
	{
		List<Playrecord> list = new ArrayList<Playrecord>();
		SQLiteDatabase db = dbhelper.getDatabase(MyDBHelper.READ);
		Cursor cursor = db.rawQuery("select c.courseid,c.coursename,c.fileurl,c.filepath,c.state,p.playtime,p.currenttime,p.username from PlayrecordTab p join CourseTab c on c.courseid = p.courseid where p.username =?", new String[]{username});
		while(cursor.moveToNext())
		{
			int state = cursor.getInt(4);
			String filepath=null;
			if(state==2)
			{
				filepath=cursor.getString(3);
			}
			Playrecord loader = new Playrecord(cursor.getString(0),cursor.getString(1),cursor.getString(2),filepath,cursor.getString(5),cursor.getInt(6),cursor.getString(7));
			list.add(loader);
		}
		cursor.close();
		dbhelper.closeDb();
		return list;
	}
	//����
	public void saveOrUpdate(Playrecord r)
	{
		SQLiteDatabase db =  dbhelper.getDatabase(MyDBHelper.WRITE);
		Cursor cursor = db.rawQuery("select * from PlayrecordTab where courseid = ? and username=?", new String[]{r.getCourseId(),r.getUsername()});
		if(cursor.getCount()==0)
		{
			cursor.close();
			db.beginTransaction();
			try{
					db.execSQL("insert into PlayrecordTab(courseid,currenttime,username)values(?,?,?)",
							new Object[]{r.getCourseId(),r.getCurrentTime(),r.getUsername()});
				db.setTransactionSuccessful();
			}finally{
				db.endTransaction();
			}
		}else
		{
			//����
			Log.d(TAG, "����");
			cursor.close();
			db.beginTransaction();
			try{
					System.out.println("currenttime:"+r.getCurrentTime());
					db.execSQL("update PlayrecordTab set currenttime = ? where username = ? and courseid = ?",
							new Object[]{r.getCurrentTime(),r.getUsername(),r.getCourseId()});
				db.setTransactionSuccessful();
			}finally{
				db.endTransaction();
			}
		}
		dbhelper.closeDb();
	}
	//����
	public Playrecord findRecord(String courseid,String username)
	{
		Playrecord record = null;
		SQLiteDatabase db =  dbhelper.getDatabase(MyDBHelper.READ);
		Cursor cursor = db.rawQuery("select courseid,playtime,currenttime,username from PlayrecordTab where courseid = ? and username = ?", new String[]{courseid,username});
		if(cursor.moveToNext())
		{
			record = new Playrecord(cursor.getString(0),cursor.getString(1),cursor.getInt(2),cursor.getString(3));
		}
		cursor.close();
		dbhelper.closeDb();
		return record;
	}
}
